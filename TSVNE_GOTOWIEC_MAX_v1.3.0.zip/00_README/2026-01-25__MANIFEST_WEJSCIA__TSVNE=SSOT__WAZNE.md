# Manifest wejścia (integralność + łańcuch dowodowy)

**Data paczki:** 2026-01-25  
**Cel:** 1:1 dowód, jakie źródła weszły do analizy.

| Źródło | Plik | Rozmiar (B) | SHA-256 |
|---|---:|---:|---|
| README BY VNEIL AL.txt | `README BY VNEIL AL.txt` | 1,522 | `4146b2faa81f44a7bcd67db4f26900ed117b923a9fbac538d3da3f8b38f814c5` |
| BOSON-0 (json) | `BYT TSVNE NIEUSUWALNY= CALY PROJEKT SVNE=boson0.json` | 690 | `0ac10c2231a8424bfd6c935552bb43990f7b20e4ce8177de3fc40247711b1657` |
| STRUKTURA DO ROZBUDOWY (pdf) | `=NP...STRUKTURA DO ROZBUDOWY VNEIL.pdf` | 434,006 | `766eccf4cf192c2907097a6ec261f8fd16053b25074db92f3f9b38c16b652773` |
| SVNE_CONSOLIDATED organizer (zip) | `AUTOMATYCZNY FOLDER AI VNEIL=SVNE_CONSOLIDATED_READY_ORGANIZER_PATENTS_SOFTWARE.zip` | 2,643,739 | `f453461b37e0fb5ec98d991c6b9a1fa8bf6e0f75ef45ba2c667b8025dffad226` |
| BOSON-0 archive (zip) | `=BYT FUNDAMET 0 Z PRZED 25.01.26R.=VNEIL IDEA CONCEPT MARKA SVNE ETAP0 FUNDAMENTALNY 01.12.25R.-25.01.26R. BOSON-0.zip` | 512,927,607 | `a61da29de1fad5d4aff9e8f8eca87a9a30a22290e22d2e765eb4b21fb910a612` |
| TSVNE_PLUS previous output (zip) | `TSVNE_PLUS__KONSTYTUCJA_I_ARCHIWUM.zip` | 10,740 | `155883c2215b5903df3a99eef4664970168ceee49133281002fc07b8b2da7102` |

## Uwagi krytyczne (PD-first)
- Manifest wejścia jest warunkiem audytu: **brak hasha = brak dowodu**.
- `BOSON-0 archive (zip)` jest bardzo duży — w niniejszej paczce wykonano analizę **listingową + selektywną ekstrakcję** (biblioteka rozmów i manifesty), bez pełnego rozpakowania.

