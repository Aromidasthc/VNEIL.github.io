# Kontekst nazwy pliku — „=AKTUALNY EXPORT CHATGPT= PODSTAWA.f1f944fdd7e50ea584ccab895e20dbbe9d1a9e831172c058440d1b5248ce1879-2026-01-25-03-28-35-4c63dc10adc846a0a17c6188d1b6fa5f.zip”

**Data analizy:** 2026-01-25 (Europe/Warsaw)

## Rozbiór nazwy
- `=AKTUALNY EXPORT CHATGPT=` — snapshot źródłowy (dowód).
- `PODSTAWA` — baseline do biblioteki rozmów i SSOT.
- Segmenty hash/UID — identyfikatory dowodowe.
- `2026-01-25-03-28-35` — timestamp z nazwy (czas z nazwy).

## Reguła sortowania (nadrzędna)
1. `90_ARCHIVE_ORIGINAL/` (read-only dowód)
2. `02_LIBRARY/` (transkrypty + assistant_only 1:1)
3. manifesty SHA-256

## Dowód integralności
- SHA-256: `f60e8652c618b62964926de1ec5de5c6d62b979eabea445669ac8a0c5c32c21c`
- Rozmiar (B): 59,747,646
