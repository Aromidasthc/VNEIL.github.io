# Release Note — TSVNE Konstytucja v1.3.0 FULL (PATCH)

**Data:** 2026-01-25 (Europe/Warsaw)  
**Owner:** ARKADIUSZ LEJSZO  

## Co to jest
Ta paczka to **PATCH** do bazowej paczki:
`TSVNE_PLATFORM_AGENT_GOTOWIEC_MAX__2026-01-25__ARKADIUSZ_LEJSZO__WAZNE.zip`
(hash bazowy: `8AB0...`)

## Co dodaje
- Konstytucja v1.3.0 FULL (superset; Appendix A = v1.0.0 1:1)
- Coverage Matrix v1.0.0 → v1.3.0 FULL

## Instalacja
1. Rozpakuj bazowy ZIP do folderu.
2. Rozpakuj ten PATCH ZIP **nad** tamtym folderem (z zachowaniem ścieżek).
3. Sprawdź, że istnieje plik:
   `00_GOVERNANCE/2026-01-25__KONSTYTUCJA_TSVNE_PLUS_v1.3.0_FULL__ARKADIUSZ_LEJSZO__WAZNE.md`

## Dowód (PD‑First)
Zobacz `00_README/2026-01-25__PATCH_MANIFEST__KONSTYTUCJA_v1.3.0_FULL.json`
