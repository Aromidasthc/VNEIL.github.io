# Konstytucja TSVNE+ (MASTER) — v1.2.0

**Data:** 2026-01-25 (Europe/Warsaw)  
**Owner:** ARKADIUSZ LEJSZO  
**Kotwica:** BOSON‑0::TSVNE  
**Tryb:** Legal‑First · NDA‑First · PD‑First · SSOT

## Fundament BOSON‑0
BOSON‑0 jest bytem fundamentalnym i niemodyfikowalnym. Dokument sprzeczny z BOSON‑0 jest nieważny.

## Eksport ChatGPT = PODSTAWA
Eksport o prefiksie `=AKTUALNY EXPORT CHATGPT= PODSTAWA*` jest dowodem źródłowym:
- przechowywany w `90_ARCHIVE_ORIGINAL/`,
- przetwarzany do `02_LIBRARY/` jako transkrypt + `assistant_only` (1:1),
- objęty manifestami SHA‑256.

## AI Agent TSVNE (MAX)
Agent jest kontrolowanym wykonawcą. Minimalne warstwy: policy → plan → execution(sandbox) → verify(PD-first) → memory(classification) → observer(evidence).  
Gotowiec: `05_AGENT_PLATFORM/TSVNE_AGENT_PLATFORM__GOTOWIEC/`

## Skala realizmu 0–20L
Wymagana w dokumentach strategicznych.

## Ocena realizmu 0–20L
- Platform + biblioteka + governance: **17/20L**
