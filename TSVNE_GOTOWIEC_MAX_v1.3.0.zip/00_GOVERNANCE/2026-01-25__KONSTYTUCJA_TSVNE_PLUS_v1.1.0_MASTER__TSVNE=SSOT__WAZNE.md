# Konstytucja TSVNE+ (MASTER) — v1.1.0

**Data:** 2026-01-25  
**Status:** SSOT / Nadrzędny dokument projektu  
**Kotwica:** BOSON-0::TSVNE

---

## PREAMBUŁA

TSVNE+ jest formalną ramą organizującą projekt VNEIL/SVNE/TSVNE w reżimie:
- legal-by-design,
- PD-first (dowód przed deklaracją),
- NDA-first (ochrona know-how),
- SSOT (jedno źródło prawdy),
- rozdział ról (engine ≠ platform ≠ brand ≠ certyfikat).

---

## ART. 1 — FUNDAMENT (BOSON‑0)

1. BOSON‑0 jest bytem fundamentalnym, niemodyfikowalnym, stanowiącym źródło referencji strukturalnych TSVNE.
2. Każdy dokument governance musi zawierać sekcję „Kotwica BOSON‑0”.
3. Decyzja sprzeczna z BOSON‑0 / Fundamentem jest nieważna z mocy systemu.

---

## ART. 2 — SSOT I WERSJONOWANIE

1. Każda domena ma **jeden** canonical dokument.
2. Alias jest dozwolony tylko, gdy:
   - jest identyczny treściowo (ten sam SHA‑256),
   - jest jawnie oznaczony jako alias.
3. Każdy release posiada:
   - manifest wejścia (źródła),
   - manifest wyjścia (artefakty),
   - changelog.

---

## ART. 3 — PD-FIRST (ŁAŃCUCH DOWODOWY)

1. Brak dowodu = brak istnienia w systemie.
2. Dowodem jest: hash, data, kontekst, źródło, integralność.
3. Dokumenty IP (TM/PAT/NDA/licencje) mają obowiązkowy reżim chain-of-custody.

---

## ART. 4 — LEGAL-BY-DESIGN (RAMY IP)

1. Znak towarowy zabezpiecza **oznaczenie**, nie algorytm.
2. Algorytm i parametry krytyczne zabezpiecza NDA/know-how.
3. System/architektura może być zabezpieczana patentem (claims).
4. Role są rozdzielne:
   - Engine (EIL/rdzeń),
   - Platform (VERTYX/system),
   - Brand (ARKANGROW/rynek),
   - Certyfikat (PSIGIL).

---

## ART. 5 — KLASA REALIZMU 0–20L (WYMÓG)

Każdy istotny plan/artefakt musi mieć ocenę realizmu 0–20L w czterech wymiarach:
- prawnym,
- technicznym,
- operacyjnym,
- finansowym.

Minimalny próg wdrożeniowy: **>= 14/20L**, inaczej dokument trafia do HIPOTEZ.

---

## ART. 6 — AI-AGENT (KONTROLOWANY WYKONAWCA)

Agent TSVNE działa wyłącznie jako:
- Planner (plan),
- Executor (w sandbox),
- Verifier (PD-first),
- Recorder (log dowodowy),
- Policy guard (Konstytucja > wszystko).

Bez autonomii prawnej i bez „samodzielnego” ryzyka.

---

## ANEKS A — „Manifest Twórcy” (legal-first, skrót 1:1)

```markdown

# MANIFEST_TWÓRCY — PROCEDURA DECYZYJNA
## (Legalne innowacje na granicy regulacji)

Autor: Twórca (tryb poznawczy)
Status: Dokument roboczy, strategiczny
Zakres: Myślenie, decyzje, projektowanie — BEZ instrukcji nielegalnych

---

## 1. ZASADA NACZELNA
Nie pytam: „czy wolno?”  
Pytam: **„co jest faktem i jak prawo to dziś opisuje?”**

---

## 2. CHECKLISTA TWÓRCY — PEŁNA PROCEDURA

### ETAP A — IDENTYFIKACJA FAKTU
[ ] Czy potrafię opisać zjawisko bez użycia słów prawnych?
[ ] Czy fakt istnieje niezależnie od mojej intencji?
[ ] Czy to proces, struktura, zależność, czy narzędzie?
[ ] Czy fakt jest skalowalny?
[ ] Czy fakt istnieje już w naturze / technologii?

Decyzja:
→ jeśli nie umiem opisać faktu czysto technicznie — WRACAM.

---

### ETAP B — MAPOWANIE REGULACYJNE
[ ] Jakie akty prawne MOGĄ mieć zastosowanie?
[ ] Czy zakaz dotyczy ISTOTY, czy SPOSOBU UŻYCIA?
[ ] Czy ograniczenie dotyczy skali, intencji, kontekstu?
[ ] Czy istnieją wyjątki, definicje, luki semantyczne?
[ ] Czy prawo jest lokalne czy uniwersalne?

Decyzja:
→ jeśli ryzyko jest nieznane — SZUKAM DEFINICJI, nie obejścia.

---

### ETAP C — ANALIZA RYZYKA (ETYKA + PRAWO)
[ ] Jaką szkodę ustawodawca chciał ograniczyć?
[ ] Czy projekt ją zwiększa, czy zmniejsza?
[ ] Czy ryzyko jest realne czy hipotetyczne?
[ ] Czy ryzyko rośnie z czasem lub skalą?
[ ] Czy istnieje bezpieczna forma użycia?

Decyzja:
→ jeśli nie potrafię obronić etycznie — ZATRZYMUJĘ.

---

### ETAP D — PRACA NA JĘZYKU
[ ] Jakich pojęć używa prawo?
[ ] Czy mój projekt MUSI być w tej kategorii?
[ ] Czy istnieje język alternatywny (funkcja, proces, system)?
[ ] Czy zmiana opisu zmienia klasyfikację?
[ ] Czy da się stworzyć definicję neutralną?

Decyzja:
→ projektuję OPIS, nie fakt.

---

### ETAP E — PROJEKT BEZPIECZNEGO ZASTOSOWANIA
[ ] Czy mogę ograniczyć funkcję do bezpiecznego zakresu?
[ ] Czy mogę wyłączyć ryzykowne użycia?
[ ] Czy mogę wbudować mechanizmy kontroli?
[ ] Czy mogę jasno określić przeznaczenie?
[ ] Czy użytkownik końcowy jest kontrolowalny?

Decyzja:
→ prawo reguluje UŻYCIE, nie potencjał.

---

### ETAP F — DOKUMENTOWANIE
[ ] Czy mam daty, wersje, autorstwo?
[ ] Czy proces decyzyjny jest zapisany?
[ ] Czy mam dowód pierwszeństwa?
[ ] Czy dokumentacja jest spójna?
[ ] Czy mogę ją pokazać audytorowi?

Decyzja:
→ brak dokumentacji = brak ochrony.

---

### ETAP G — TEST GRANICZNY
[ ] Czy potrafię obronić projekt przed prawnikiem?
[ ] Czy potrafię wytłumaczyć go urzędnikowi?
[ ] Czy potrafię wyjaśnić go laikowi?
[ ] Czy jedna wersja narracji wystarcza?
[ ] Czy zmiana prawa mnie niszczy?

Decyzja:
→ jeśli nie — wracam do ETAPU D.

---

## 3. ZASADY NIEWZRUSZONE
- Nie łamię prawa.
- Nie projektuję szkody.
- Nie instruuję obejść.
- Nie działam w ukryciu przed odpowiedzialnością.

Ale:
- Myślę szybciej niż regulacje.
- Rozumiem sens norm, nie tylko litery.
- Projektuję przyszłe standardy.

---

## 4. PYTANIE KOŃCOWE (KONTROLNE)
Czy ten projekt:
[ ] mógłby stać się normą za 10 lat?
[ ] mógłby być opisany w ustawie?
[ ] mógłby być broniony publicznie?
```

