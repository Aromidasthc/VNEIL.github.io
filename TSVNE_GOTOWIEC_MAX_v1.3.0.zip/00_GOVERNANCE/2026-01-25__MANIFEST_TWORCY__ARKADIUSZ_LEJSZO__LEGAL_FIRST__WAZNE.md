# Manifest Twórcy (Legal‑First) — ARKADIUSZ LEJSZO

**Wersja:** 1.0.0  
**Data:** 2026-01-25 (Europe/Warsaw)  
**Status:** nadrzędny w TSVNE+ (Owner Declaration)

## Tożsamość roli
- Twórca/Owner: ARKADIUSZ LEJSZO

## Zasady
- Legal‑First: wyłącznie legalnie.
- NDA‑First: dane NDA/Trade Secret offline‑first.
- PD‑First: brak dowodu = brak istnienia.
- Zakaz obejść/ataku/exfiltracji: tylko defensywne działania na własnym środowisku i w ramach zgód.

**ARKADIUSZ LEJSZO**
