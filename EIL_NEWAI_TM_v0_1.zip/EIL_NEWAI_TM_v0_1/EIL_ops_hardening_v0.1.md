# EIL NEWAI TM — OPS & Hardening (v0.1)
**Data:** 2026-01-22  
**Cel:** zabezpieczenia praktyczne: dane, urządzenia, sieć, logi 🛡️

---

## 1) Model zagrożeń (skrót)
### Aktywa (co chronimy)
- Rodzina (bezpieczeństwo, prywatność), finanse, reputacja
- IP/NDA, plany, schematy, kody
- Dostępy (konta, hasła, klucze)

### Przeciwnik (przykłady)
- Phishing / socjotechnika
- Malware / kradzież sesji
- Wycieki danych przez nadmiar informacji (oversharing)

---

## 2) Zasada „Zero C2 w czacie”
**C2 = tylko lokalnie, szyfrowane.**  
Do rozmów używaj: streszczeń, abstraktów, pseudonimów, uogólnień.

---

## 3) Sejf danych (minimum)
### 3.1 Szyfrowanie i dostęp
- Full Disk Encryption na urządzeniach
- Hasła: menedżer haseł + długie frazy
- 2FA: preferuj klucz sprzętowy (tam gdzie możliwe)

### 3.2 Backup 3-2-1
- 3 kopie, 2 nośniki, 1 offline (odłączona)
- Test odtwarzania raz na miesiąc

---

## 4) Higiena kont i urządzeń
- Oddzielne konta: **Operator (Admin)** i **Uczeń (User)**
- Aktualizacje systemu + przeglądarki
- Minimalna liczba rozszerzeń w przeglądarce
- Blokada ekranu, automatyczne wygaszanie
- Antymalware (lub systemowe mechanizmy ochrony)

---

## 5) Sieć (domowa „strefa AI”)
- Jeśli możesz: oddzielna sieć/Wi‑Fi dla urządzeń „AI”
- Ogranicz ruch wychodzący dla usług niepotrzebnych
- Jeśli wariant lokalny: rozważ tryb offline dla modułów krytycznych

---

## 6) RAG / baza wiedzy (Ogród)
### Zasady
- Do Ogrodu trafia C0/C1.  
- C2 tylko w osobnym, szyfrowanym repo — najlepiej **bez integracji z narzędziami online**.

### Struktura folderów (propozycja)
- `Ogród/C0_public/`
- `Ogród/C1_private/`
- `Sejf/C2_secret/` (szyfrowany)

### Wersjonowanie
- `rules/` (polityki)
- `logs/` (kronika decyzji)
- `kb/` (wiedza)

---

## 7) Kronika (audyt) — co logować
Loguj:
- temat, data, klasa danych (C0/C1/C2)
- decyzja i powód
- ryzyka i kroki redukcji

Nie loguj:
- haseł, kluczy, tokenów
- pełnych danych identyfikacyjnych
- surowych treści C2

---

## 8) Checklista „przed rozmową”
1) Klasa danych: C0/C1/C2  
2) Usuń identyfikatory (imiona, adresy, numery, klucze)  
3) Zastąp szczegóły abstraktem  
4) Ustal format odpowiedzi (plan/checklista)  
5) Zaplanuj test weryfikacyjny

---

## 9) Checklista „po rozmowie”
1) Zapisz w Kronice: decyzję + ryzyka + kroki  
2) Jeśli pojawiło się C2 — przenieś do Sejfu (lokalnie), usuń z notatek online  
3) Zaktualizuj politykę (jeśli wyszła luka)

---

## 10) Minimalny standard dla Ucznia (syn)
- Zasada 3 pytań:
  1) Jaka klasa danych?
  2) Jaki cel?
  3) Jak sprawdzę wynik?
- Zasada „zero sekretów”
- Zasada „najpierw checklista, potem działanie”
