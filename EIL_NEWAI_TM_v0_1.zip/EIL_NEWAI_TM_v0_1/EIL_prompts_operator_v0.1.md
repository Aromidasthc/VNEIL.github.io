# EIL NEWAI TM — Makra promptów (Operator) (v0.1)
**Data:** 2026-01-22  
Używaj jako gotowców. Wszystko zakłada **C0/C1** (bez C2). ⚙️

---

## 1) LATARNIA — decyzja + checklista
**Wklej:**
Cel: {"..."}
Klasa danych: C0/C1
Ograniczenia: {"czas/budżet/narzędzia"}
Proszę odpowiedz formatem EIL:
1) decyzja,
2) uzasadnienie (3–5 pkt),
3) top 3 ryzyka + redukcja,
4) checklista kroków,
5) test weryfikacyjny.

---

## 2) KUŹNIA — architektura systemu
Zaprojektuj architekturę dla: {"opis systemu"}
Wymagania: {"bezpieczeństwo/skalowanie/offline/logowanie"}
Ograniczenia: {"sprzęt/budżet/czas"}
Daj:
- warstwy,
- komponenty,
- przepływy danych,
- model zagrożeń,
- MVP (v0.1) + roadmapa.

---

## 3) Red-team defensywny (bez hackowania)
Przeprowadź analizę ryzyk dla: {"system/proces"}
Zakres: tylko legalne, defensywne.
Wypisz:
- wektory błędów/wycieków (organizacyjne, dane, UX),
- symptomy,
- zabezpieczenia,
- procedury reakcji.

---

## 4) „Abstrakt zamiast sekretu” (C2-safe)
Mam informację wrażliwą (C2), której nie mogę ujawnić.
Oto bezpieczny abstrakt: {"abstrakt bez identyfikatorów"}
Na tej podstawie:
- zaproponuj 3 strategie,
- porównaj trade-offy,
- daj checklistę wdrożenia.

---

## 5) Nauka / mentoring (Twoje „TSVNE” w praktyce)
Naucz mnie: {"temat"}
Poziom: {"0/1/2"} (0=podstawy, 2=zaawansowane)
Wymagam:
- teoria minimalna,
- ćwiczenie praktyczne,
- kryterium poprawności,
- typowe błędy.
