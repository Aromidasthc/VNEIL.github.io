# Pakiet EIL NEWAI TM v0.1
**Data:** 2026-01-22

## Zawartość
1) `EIL_policy_v0.1.md` — Konstytucja (misja, role, klasy danych, protokół)
2) `EIL_ops_hardening_v0.1.md` — OPS (sejf, backup, sieć, logi, checklisty)
3) `EIL_prompts_operator_v0.1.md` — Makra promptów (Operator)
4) `EIL_prompts_student_v0.1.md` — Makra promptów (Uczeń)

## Jak używać (minimum)
- Zacznij od `EIL_policy_v0.1.md`
- Wprowadź checklisty z OPS
- Korzystaj z makr promptów (Operator/Uczeń)

## Uwaga
Ten pakiet jest **defensywny i legalny**. Nie zawiera instrukcji obejścia zabezpieczeń ani działań ofensywnych.
