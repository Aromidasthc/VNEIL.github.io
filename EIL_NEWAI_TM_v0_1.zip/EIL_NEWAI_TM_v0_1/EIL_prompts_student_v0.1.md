# EIL NEWAI TM — Makra promptów (Uczeń) (v0.1)
**Data:** 2026-01-22  
Zasada: **zero sekretów**, tylko C0/C1. 🎓

---

## 0) Start (obowiązkowy)
Klasa danych: C0/C1  
Cel: {"1 zdanie"}  
Jak sprawdzę wynik: {"test/źródło/eksperyment"}  

---

## 1) Zrozumienie tematu
Wyjaśnij mi: {"temat"}
Wymagam:
- prosto i krótko,
- przykład,
- 5 pytań kontrolnych na koniec.

---

## 2) Ćwiczenie
Daj mi zadanie z: {"temat"}
- poziom trudności: {"łatwe/średnie"}
- kryteria zaliczenia
- podpowiedzi, ale nie dawaj od razu rozwiązania.

---

## 3) Sprawdzenie odpowiedzi (feedback)
Oto moja odpowiedź: {"..."}
Oceń:
- co jest poprawne,
- co jest błędne,
- jak poprawić,
- jeden kolejny krok nauki.

---

## 4) Bezpieczeństwo w sieci (defensywnie)
Chcę być bezpieczny online.
Daj mi:
- 10 zasad higieny,
- jak rozpoznać phishing,
- co zrobić gdy podejrzewam wyciek.
