# POLICY SPEC (CORE-7)

Policy to JSON z trzema kluczami:

```json
{
  "version": "0.1",
  "entities": [{"id":"ssot_core","label":"SSOT Core","enabled":true}],
  "depends": {"tsvne_core":["legal_core","pd_engine","ssot_core"]},
  "invariants": [
    {
      "id":"INV_SSOT_REQUIRED",
      "desc":"SSOT musi istnieć",
      "involves":["ssot_core"],
      "expr": {"op":"exists","id":"ssot_core"}
    }
  ]
}
```

## `expr` — bezpieczny AST (bez eval)

Obsługiwane operatory:

- `{"op":"true"}` / `{"op":"false"}`
- `{"op":"exists","id":"entity_id"}` → czy byt istnieje
- `{"op":"flag","key":"legal"}` → flaga SYSTEM
- `{"op":"not","arg": <expr>}`
- `{"op":"and","args":[<expr>,...]}`
- `{"op":"or","args":[<expr>,...]}`
- `{"op":"eq","a":<expr>,"b":<expr>}`
- `{"op":"implies","a":<expr>,"b":<expr>}`

Wartości `eq` mogą być bool albo string/number (jeśli dostarczysz przez `{"op":"value","value":...}`).

### Przykład
„Jeśli legal=true, to ssot_core musi istnieć”:

```json
{
  "id":"INV_LEGAL_IMPLIES_SSOT",
  "desc":"LEGAL => SSOT",
  "involves":["legal_core","ssot_core"],
  "expr":{
    "op":"implies",
    "a":{"op":"flag","key":"legal"},
    "b":{"op":"exists","id":"ssot_core"}
  }
}
```
