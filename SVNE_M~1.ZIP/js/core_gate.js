// CORE-3: Contradiction Gate / Preflight (ALLOW/DENY)
export function applyAction(state, a, dependsMap) {
  if (a.type === "REMOVE_ENTITY") state.setExists(a.payload.id, false);
  if (a.type === "RESTORE_ENTITY") state.setExists(a.payload.id, true);
  if (a.type === "SET_FLAG") state.SYSTEM[a.payload.key] = a.payload.value;

  if (a.type === "RESTORE_CLOSURE") {
    const id = a.payload.id;
    const stack = [id];
    const seen = new Set();
    while (stack.length) {
      const cur = stack.pop();
      if (seen.has(cur)) continue;
      seen.add(cur);
      const deps = dependsMap[cur] || [];
      for (const d of deps) {
        state.setExists(d, true);
        stack.push(d);
      }
    }
  }
  return state;
}

export function applyActions(state, actions, dependsMap) {
  for (const a of actions) applyAction(state, a, dependsMap);
  return state;
}

export function brokenInvariants(state, invariants) {
  return invariants.filter(inv => !inv.check(state));
}

export async function preflightBatch(stateFactory, actions, invariants, dependsMap) {
  const s = stateFactory().clone();
  applyActions(s, actions, dependsMap);
  const broken = brokenInvariants(s, invariants);
  if (!broken.length) return { allow: true };
  return {
    allow: false,
    broken: broken.map(b => ({ id: b.id, desc: b.desc }))
  };
}
