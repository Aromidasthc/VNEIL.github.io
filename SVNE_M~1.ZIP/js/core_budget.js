// CORE-5: Necessity Budgeter
import { buildReverseDeps, explainRemoval } from "./core_graph.js";

export function transitiveDependentsCount(id, reverseDeps) {
  const seen = new Set([id]);
  const q = [id];
  let count = 0;
  while (q.length) {
    const cur = q.shift();
    const nexts = reverseDeps[cur] || [];
    for (const nx of nexts) {
      if (!seen.has(nx)) {
        seen.add(nx);
        q.push(nx);
        count++;
      }
    }
  }
  return count;
}

export function invariantsTouchingEntity(id, invariants) {
  return invariants.filter(inv => (inv.involves || []).includes(id)).length;
}

export function removalImpact(id, stateFactory, invariants, reverseDeps) {
  const exp = explainRemoval(id, stateFactory, invariants, reverseDeps);
  if (!exp.contradiction) return { breaks: 0, first: null, pathLen: null };

  const s = stateFactory().clone();
  s.setExists(id, false);
  const broken = invariants.filter(inv => !inv.check(s));
  const pathLen = exp.path ? exp.path.length : null;
  return { breaks: broken.length, first: exp.brokenInvariant, pathLen };
}

export function necessityScore(id, stateFactory, invariants, reverseDeps) {
  const dep = transitiveDependentsCount(id, reverseDeps);
  const inv = invariantsTouchingEntity(id, invariants);
  const imp = removalImpact(id, stateFactory, invariants, reverseDeps);

  const w_breaks = 10, w_dep = 2, w_inv = 1;
  const pathBonus = (imp.pathLen && imp.pathLen > 0) ? (3 / imp.pathLen) : 0;
  const score = (w_breaks * imp.breaks) + (w_dep * dep) + (w_inv * inv) + pathBonus;

  return { score, dep, inv, ...imp };
}

export function rankNecessity(entities, stateFactory, invariants, dependsMap) {
  const reverseDeps = buildReverseDeps(dependsMap);
  const rows = entities.map(e => {
    const m = necessityScore(e.id, stateFactory, invariants, reverseDeps);
    return {
      id: e.id,
      score: +m.score.toFixed(3),
      breaks: m.breaks,
      dependents: m.dep,
      inv_touch: m.inv,
      first_broken: m.first ? m.first.id : null,
      path_len: m.pathLen
    };
  });
  rows.sort((a,b) => b.score - a.score);
  return rows;
}
