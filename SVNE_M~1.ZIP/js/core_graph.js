// CORE-2: Dependency Graph + Explain Engine
export function buildReverseDeps(dependsMap) {
  const rev = {};
  for (const [node, deps] of Object.entries(dependsMap)) {
    (deps || []).forEach(d => {
      rev[d] = rev[d] || [];
      rev[d].push(node);
    });
  }
  return rev;
}

export function shortestPathReverseDeps(removedId, targetId, reverseDeps) {
  if (removedId === targetId) return [removedId];
  const q = [removedId];
  const prev = new Map([[removedId, null]]);
  while (q.length) {
    const cur = q.shift();
    const nexts = reverseDeps[cur] || [];
    for (const nx of nexts) {
      if (!prev.has(nx)) {
        prev.set(nx, cur);
        if (nx === targetId) {
          const path = [];
          let p = nx;
          while (p !== null) { path.push(p); p = prev.get(p); }
          return path.reverse();
        }
        q.push(nx);
      }
    }
  }
  return null;
}

export function explainRemoval(removedId, stateFactory, invariants, reverseDeps) {
  const state = stateFactory().clone();
  state.setExists(removedId, false);

  const broken = [];
  for (const inv of invariants) {
    if (!inv.check(state)) broken.push(inv);
  }
  if (!broken.length) return { contradiction: false };

  const inv = broken[0];
  let bestPath = null;
  for (const t of inv.involves || []) {
    const p = shortestPathReverseDeps(removedId, t, reverseDeps) || (removedId === t ? [removedId] : null);
    if (p && (!bestPath || p.length < bestPath.length)) bestPath = p;
  }

  return {
    contradiction: true,
    brokenInvariant: { id: inv.id, desc: inv.desc },
    path: bestPath
  };
}
