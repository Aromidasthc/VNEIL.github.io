// CORE-7: Policy Compiler (JSON -> DEPENDS + INVARIANTS + ENTITIES) without eval
// Safe AST interpreter for invariant expressions.
export function compilePolicy(policy, ctx) {
  // ctx: { SYSTEM, ENTITIES, exists(id)->bool }
  // returns { entities, depends, invariants }
  if (!policy || typeof policy !== "object") throw new Error("Policy must be an object");
  const version = String(policy.version || "0.0");
  const entities = Array.isArray(policy.entities) ? policy.entities : [];
  const depends = policy.depends && typeof policy.depends === "object" ? policy.depends : {};
  const invs = Array.isArray(policy.invariants) ? policy.invariants : [];

  const compiledInvariants = invs.map(inv => {
    if (!inv || typeof inv !== "object") throw new Error("Invalid invariant item");
    if (!inv.id || !inv.expr) throw new Error("Invariant requires id and expr");
    const check = (state) => evalExpr(inv.expr, state);
    return {
      id: inv.id,
      desc: String(inv.desc || inv.id),
      involves: Array.isArray(inv.involves) ? inv.involves : [],
      expr: inv.expr,
      check
    };
  });

  return { version, entities, depends, invariants: compiledInvariants };
}

export function evalExpr(expr, state) {
  // state: { SYSTEM, exists(id) }
  if (!expr || typeof expr !== "object") throw new Error("expr must be object");
  const op = expr.op;

  switch (op) {
    case "true": return true;
    case "false": return false;
    case "value": return expr.value;
    case "exists": {
      const id = String(expr.id);
      return state.exists(id) === true;
    }
    case "flag": {
      const key = String(expr.key);
      return state.SYSTEM[key];
    }
    case "not": return !evalExpr(expr.arg, state);
    case "and": {
      const args = Array.isArray(expr.args) ? expr.args : [];
      for (const a of args) if (!evalExpr(a, state)) return false;
      return true;
    }
    case "or": {
      const args = Array.isArray(expr.args) ? expr.args : [];
      for (const a of args) if (evalExpr(a, state)) return true;
      return false;
    }
    case "eq": {
      const a = evalExpr(expr.a, state);
      const b = evalExpr(expr.b, state);
      return a === b;
    }
    case "implies": {
      const a = !!evalExpr(expr.a, state);
      const b = !!evalExpr(expr.b, state);
      return (!a) || b;
    }
    default:
      throw new Error("Unsupported op: " + op);
  }
}
