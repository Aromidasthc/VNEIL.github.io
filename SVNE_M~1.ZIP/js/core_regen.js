// CORE-6: Auto-Repair REGEN (beam search)
import { applyActions, brokenInvariants } from "./core_gate.js";
import { rankNecessity } from "./core_budget.js";

function baselineSnapshot(stateFactory) {
  return stateFactory().clone();
}

function inverseAction(action, base) {
  if (action.type === "REMOVE_ENTITY") return { type: "RESTORE_ENTITY", payload: { id: action.payload.id } };
  if (action.type === "SET_FLAG") {
    const key = action.payload.key;
    const prev = base.SYSTEM[key];
    return { type: "SET_FLAG", payload: { key, value: prev } };
  }
  return null;
}

function repairCandidates(brokenInvs, originalActions, base) {
  const cands = [];

  for (let i = originalActions.length - 1; i >= 0; i--) {
    const inv = inverseAction(originalActions[i], base);
    if (inv) cands.push({ kind: "UNDO", fix: [inv], why: `Undo ${originalActions[i].type}` });
  }

  for (const inv of brokenInvs) {
    // general restore for involves
    for (const id of (inv.involves || [])) {
      cands.push({ kind: "RESTORE", fix: [{ type: "RESTORE_ENTITY", payload: { id } }], why: `Restore: ${id}` });
      cands.push({ kind: "CLOSURE", fix: [{ type: "RESTORE_CLOSURE", payload: { id } }], why: `Restore closure: ${id}` });
    }
    // common flags
    if (inv.id === "INV_LEGAL_ON") cands.push({ kind:"RULE", fix:[{ type:"SET_FLAG", payload:{ key:"legal", value:true }}], why:"Enable LEGAL" });
    if (inv.id === "INV_PD_ON") cands.push({ kind:"RULE", fix:[{ type:"SET_FLAG", payload:{ key:"pd", value:true }}], why:"Enable PD" });
  }

  const uniq = new Map();
  for (const c of cands) {
    const k = JSON.stringify(c.fix);
    if (!uniq.has(k)) uniq.set(k, c);
  }
  return [...uniq.values()];
}

function planScore(plan, necessityMap) {
  const costChanges = plan.fixes.length;
  let touchPenalty = 0;

  for (const a of plan.fixes) {
    const id = a.payload?.id;
    if (id && necessityMap.has(id)) {
      const r = necessityMap.get(id);
      touchPenalty += Math.min(5, r.score / 10);
    }
  }
  const stillBrokenPenalty = plan.allow ? 0 : (plan.broken_after?.length || 1) * 10;
  return costChanges * 3 + touchPenalty + stillBrokenPenalty;
}

export async function regenSuggest(stateFactory, entities, actions, invariants, dependsMap, opts = {}) {
  const { beamWidth = 6, maxDepth = 3, maxPlans = 5 } = opts;

  const base = baselineSnapshot(stateFactory);
  const ranking = rankNecessity(entities, stateFactory, invariants, dependsMap);
  const rankMap = new Map(ranking.map(r => [r.id, r]));

  const start = stateFactory().clone();
  applyActions(start, actions, dependsMap);
  const broken0 = brokenInvariants(start, invariants);
  if (!broken0.length) return [{ allow: true, fixes: [], score: 0, whyTrail: ["No repair needed"] }];

  let frontier = [{
    fixes: [],
    allow: false,
    broken_after: broken0.map(b => ({ id: b.id, desc: b.desc })),
    whyTrail: ["Initial fail"]
  }];

  const solutions = [];

  for (let depth = 1; depth <= maxDepth; depth++) {
    const nextFrontier = [];

    for (const node of frontier) {
      const s = stateFactory().clone();
      applyActions(s, actions, dependsMap);
      applyActions(s, node.fixes, dependsMap);

      const broken = brokenInvariants(s, invariants);
      if (!broken.length) {
        const plan = { allow: true, fixes: node.fixes, broken_after: [], whyTrail: node.whyTrail };
        plan.score = planScore(plan, rankMap);
        solutions.push(plan);
        continue;
      }

      const cands = repairCandidates(broken, actions, base);

      for (const c of cands) {
        const newFixes = node.fixes.concat(c.fix);

        const s2 = stateFactory().clone();
        applyActions(s2, actions, dependsMap);
        applyActions(s2, newFixes, dependsMap);
        const broken2 = brokenInvariants(s2, invariants);

        const plan = {
          allow: broken2.length === 0,
          fixes: newFixes,
          broken_after: broken2.map(b => ({ id: b.id, desc: b.desc })),
          whyTrail: node.whyTrail.concat([c.why])
        };
        plan.score = planScore(plan, rankMap);

        nextFrontier.push(plan);
        if (plan.allow) solutions.push(plan);
      }
    }

    nextFrontier.sort((a,b) => a.score - b.score);
    frontier = nextFrontier.slice(0, beamWidth);

    solutions.sort((a,b) => a.score - b.score);
    if (solutions.length >= maxPlans) break;
  }

  solutions.sort((a,b) => a.score - b.score);
  return solutions.slice(0, maxPlans);
}
