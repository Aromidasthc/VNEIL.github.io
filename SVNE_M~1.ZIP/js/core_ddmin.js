// CORE-4: MUS-lite ddmin
import { applyActions, brokenInvariants } from "./core_gate.js";

export function fails(stateFactory, actions, invariants, dependsMap) {
  const s = stateFactory().clone();
  applyActions(s, actions, dependsMap);
  return brokenInvariants(s, invariants).length > 0;
}

export function ddmin(items, testFn) {
  let n = 2;
  let current = items.slice();
  while (current.length >= 2) {
    const chunkSize = Math.ceil(current.length / n);
    const chunks = [];
    for (let i = 0; i < current.length; i += chunkSize) chunks.push(current.slice(i, i + chunkSize));

    let reduced = false;

    for (const c of chunks) {
      if (testFn(c)) { current = c; n = 2; reduced = true; break; }
    }
    if (reduced) continue;

    for (const c of chunks) {
      const complement = current.filter(x => !c.includes(x));
      if (complement.length && testFn(complement)) {
        current = complement;
        n = Math.max(2, n - 1);
        reduced = true;
        break;
      }
    }
    if (reduced) continue;

    if (n >= current.length) break;
    n = Math.min(current.length, n * 2);
  }
  return current;
}

export function minimalCause(stateFactory, actions, invariants, dependsMap) {
  if (!fails(stateFactory, actions, invariants, dependsMap)) return [];
  const testFn = (subset) => fails(stateFactory, subset, invariants, dependsMap);
  return ddmin(actions, testFn);
}
