// CORE-1: Time-as-Proof Ledger (tamper-evident hash-chain)
export const LEDGER = [];

const te = new TextEncoder();

export function stableStringify(x) {
  if (x === null || typeof x !== "object") return JSON.stringify(x);
  if (Array.isArray(x)) return "[" + x.map(stableStringify).join(",") + "]";
  const keys = Object.keys(x).sort();
  return "{" + keys.map(k => JSON.stringify(k) + ":" + stableStringify(x[k])).join(",") + "}";
}

export async function sha256(str) {
  const buf = await crypto.subtle.digest("SHA-256", te.encode(str));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
}

export async function appendEvent(type, payload) {
  const t = new Date().toISOString();
  const prevHash = LEDGER.length ? LEDGER[LEDGER.length - 1].hash : "GENESIS";
  const canon = stableStringify(payload);
  const hash = await sha256(prevHash + "|" + type + "|" + t + "|" + canon);

  const event = { idx: LEDGER.length, t, type, payload, prevHash, hash };
  LEDGER.push(event);
  return event;
}

export async function verifyLedger() {
  for (let i = 0; i < LEDGER.length; i++) {
    const e = LEDGER[i];
    const expectedPrev = (i === 0) ? "GENESIS" : LEDGER[i - 1].hash;
    if (e.prevHash !== expectedPrev) return { ok: false, at: i, reason: "prevHash mismatch" };

    const canon = stableStringify(e.payload);
    const expectedHash = await sha256(e.prevHash + "|" + e.type + "|" + e.t + "|" + canon);
    if (e.hash !== expectedHash) return { ok: false, at: i, reason: "hash mismatch" };
  }
  return { ok: true, count: LEDGER.length };
}
