// Optional: Mode state machine (NORMAL/TVM/REGEN) — minimal skeleton
export const MODES = {
  NORMAL: "S_NORMAL",
  TVM: "S_TVM",
  REGEN: "S_REGEN",
  AUDIT_LOCK: "S_AUDIT_LOCK"
};

export function transition(mode, signals) {
  // signals: { proofFail, hardViolation, recovered, stableWindow, proofOk, riskLow, integrityCriticalFail }
  if (signals.integrityCriticalFail) return MODES.AUDIT_LOCK;
  if (mode === MODES.NORMAL && signals.triggerTVM) return MODES.TVM;
  if (mode === MODES.TVM && (signals.proofFail || signals.hardViolation)) return MODES.REGEN;
  if (mode === MODES.REGEN && signals.recovered) return MODES.TVM;
  if (mode === MODES.TVM && signals.stableWindow && signals.proofOk && signals.riskLow) return MODES.NORMAL;
  return mode;
}
