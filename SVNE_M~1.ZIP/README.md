# SVNE · META-SIM · TSVNE (CORE-0 → CORE-7) — Offline Bundle

To paczka offline (bez zależności, bez sieci). Otwórz `index.html` w przeglądarce.

## Co zawiera
- CORE-1: Time-as-Proof Ledger (tamper-evident hash-chain)
- CORE-2: Dependency Graph + Explain Engine (ścieżka „DLACZEGO”)
- CORE-3: Contradiction Gate / Preflight (ALLOW/DENY)
- CORE-4: MUS-lite ddmin (minimalna przyczyna sprzeczności dla batcha)
- CORE-5: Necessity Budgeter (ranking krytyczności bytów)
- CORE-6: Auto-Repair REGEN (propozycje planów napraw)
- CORE-7: Policy Compiler (kompilacja DEPENDS + INVARIANTS z JSON do runtime)

## Uruchomienie
1) Rozpakuj ZIP.
2) Otwórz `index.html` (dwuklik).
   - Jeśli Twoja przeglądarka blokuje pewne funkcje na `file://`, uruchom lokalny serwer:
     - Python: `python -m http.server 8080` w katalogu paczki, potem otwórz `http://localhost:8080/`.

## Zasada bezpieczeństwa
CORE-7 **nie używa `eval`**. Zamiast tego interpretuje bezpieczny AST (zobacz `policy/policy.example.json`).

## Pliki
- index.html — aplikacja offline (UI + integracja wszystkich CORE)
- policy/policy.example.json — przykładowa polityka (entities, depends, invariants)
- js/*.js — moduły rozdzielone (dla edycji / audytu)
- docs/POLICY_SPEC.md — specyfikacja języka polityk
