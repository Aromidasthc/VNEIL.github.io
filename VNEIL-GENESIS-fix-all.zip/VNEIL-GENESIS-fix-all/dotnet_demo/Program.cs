// Purpose: Minimal ASP.NET Core API for the VNEIL‑GENESIS demo.
//
// Assumptions:
//  - Targets .NET 9.0 SDK (see dotnet_demo.csproj).
//  - No external dependencies beyond Microsoft.AspNetCore.App.
//
// Invariants:
//  - Provides GET /api/health endpoint returning JSON { status: "ok", demo: "vneil-genesis-dotnet" }.
//
// Failure modes:
//  - Port conflicts (defaults to 5000/5001).
//  - Runtime missing .NET 9.0 SDK.
//
// Example:
//   dotnet run --project dotnet_demo
//   # then curl http://localhost:5000/api/health

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container (none needed for this minimal API).

var app = builder.Build();

// Define the health endpoint
app.MapGet("/api/health", () => new { status = "ok", demo = "vneil-genesis-dotnet" });

// Run the application
app.Run();