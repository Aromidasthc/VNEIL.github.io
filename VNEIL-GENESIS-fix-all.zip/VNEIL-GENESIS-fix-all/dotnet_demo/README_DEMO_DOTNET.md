# Demo .NET — VNEIL‑GENESIS

Instrukcje uruchomienia demo .NET (Minimal API):

1. Upewnij się, że masz zainstalowany .NET SDK 9.0 lub nowszy.

2. Przejdź do katalogu `dotnet_demo`:

```bash
cd dotnet_demo
```

3. Zbuduj i uruchom aplikację:

```bash
dotnet run
# otwórz http://localhost:5000/api/health
```

Uwagi
- To demo jest minimalnym API ASP.NET Core; brak dodatkowych klas czy kontrolerów.
- Punkt `/api/health` zwraca JSON z kluczem `demo` wskazującym na projekt.