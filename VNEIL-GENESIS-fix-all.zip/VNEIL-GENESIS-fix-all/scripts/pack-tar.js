/*
 * Purpose: Create a gzipped tarball (`demo.tar.gz`) containing the minimal
 * demo runtime files. Uses the `tar` package.
 *
 * Assumptions:
 *  - This script is executed from the repository root (`npm run pack:tar`).
 *  - The `tar` package is installed.
 *
 * Invariants:
 *  - On success, `demo.tar.gz` exists in the repo root and includes
 *    `index.js`, `package.json`, `public/`, and `README_DEMO.md`.
 *
 * Failure modes:
 *  - If the tarball cannot be created, an error is thrown and the process
 *    exits with a non-zero status.
 */

const tar = require('tar');
const path = require('path');

async function createTar() {
  const dest = path.resolve(__dirname, '..', 'demo.tar.gz');
  await tar.c(
    {
      gzip: true,
      file: dest,
      cwd: path.resolve(__dirname, '..')
    },
    ['index.js', 'package.json', 'public', 'README_DEMO.md']
  );
  console.log(`Created ${dest}`);
}

createTar().catch(err => { console.error(err); process.exit(1); });