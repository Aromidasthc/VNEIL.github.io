# Demo — VNEIL‑GENESIS

Instrukcje uruchomienia demo (Windows / Linux / macOS)

1. Zainstaluj Node.js (zalecane LTS ≥ 20).

2. Zainstaluj zależności:

```bash
npm install
```

3. Uruchom demo:

```bash
npm start
# otwórz http://localhost:3000 w przeglądarce
```

4. Utwórz archiwum ZIP z demo:

```bash
npm run pack
# wygeneruje plik demo.zip w katalogu repo
```

5. Utwórz archiwum TAR z demo:

```bash
npm run pack:tar
# wygeneruje plik demo.tar.gz w katalogu repo
```

Uwagi
- Pliki demo są minimalne — `index.js` (Express 5), `public/index.html` i `package.json`.
- Jeśli działasz na Windows bez zainstalowanego Node, zainstaluj Node lub poproś o scaffold dla innego runtime.