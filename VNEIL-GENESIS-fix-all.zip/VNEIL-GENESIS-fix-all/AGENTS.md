# Agents Overview

This repository defines one or more **custom agents** used in the development workflow.  Agents describe how AI assistants (like GitHub Copilot) should behave when operating on this codebase.

## vneil-programista

The `vneil-programista` agent specification lives in `.github/agents/vneil-programista.agent.md` and provides a **TSVNE AI‑Human Hybrid Programming Model (HPM)** for deterministic, auditable software engineering.  Key aspects include:

| Attribute     | Description                                                               |
|---------------|---------------------------------------------------------------------------|
| **Standard**  | SVNE/TSVNE                                                                |
| **Role**      | Repo‑programista (strict repository engineer)                             |
| **Priorities**| legal‑only, determinism, auditability, minimal dependencies               |
| **Mode**      | Hybrid AI‑Human model (HPM) with human sign‑off for high‑risk changes     |
| **SSOT**      | TSVNE=SSOT — single source of truth governing configuration/state         |

See the agent spec for detailed rules covering non‑negotiables, engineering principles, guardrails, and the HPM pipeline.

## How to add or modify agents

1. Create a new file in `.github/agents/<name>.agent.md` following the same front‑matter structure.  Include metadata such as `name`, `description`, `target`, and any custom fields in `metadata`.
2. Write the body using Markdown.  Include sections defining legal/safety boundaries, operating mode, engineering rules, code style, and any compliance hooks.
3. If the agent introduces a new programming model, describe the pipeline and decision gates clearly.
4. Document the agent in this file (`AGENTS.md`) to help maintainers discover available agents.

Agents are version‑controlled along with the code and should evolve with repository standards.  When making breaking changes or adding new agents, ensure proper code review and alignment with the TSVNE governance documents.