// Purpose: Simple Express server for the VNEIL‑GENESIS demo.
//
// Assumptions:
// - Runs under Node.js ≥20 (see package.json).
// - Serves a static directory at '/public'.
// - Provides a health endpoint at '/api/health'.
//
// Invariants:
// - Must respond with JSON `{ status: 'ok', demo: '<name>' }` on '/api/health'.
// - Should start without throwing exceptions.
//
// Failure modes:
// - If required modules are missing, the process will throw during require().
// - If the port is already in use, the server will fail to bind.
//
// Example:
//   node index.js
//   # Navigate to http://localhost:3000/api/health in a browser.

const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', demo: 'vneil-genesis' });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Demo server running on http://localhost:${PORT}`);
});