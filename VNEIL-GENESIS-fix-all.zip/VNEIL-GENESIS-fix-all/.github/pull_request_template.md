<!--
This is a pull request template aligned with the TSVNE AI‑Human Hybrid Programming Model (HPM).
Fill out the sections below when submitting a PR.  Delete any sections that do not apply.
-->

### Scope

_Provide a concise description of what this PR changes._

### Assumptions

_List any assumptions you made while implementing this change._

### Invariants

_Describe the conditions that must remain true after this change._

### Risk class

- [ ] LOW — no human sign‑off required
- [ ] MED — moderate risk
- [ ] HIGH — requires Human Sign‑Off (see agent spec §3.3)

### Tests

_Provide instructions on how to run the tests or demos for this PR and describe the results._

### Audit notes

_List SSOT modules or configuration touched by this PR.  Confirm that no secrets or sensitive data are included._