"""
Purpose: Minimal Flask demo application for VNEIL‑GENESIS.

Assumptions:
  - The Flask dependency is installed (see requirements.txt).
  - Running Python 3.12 or later.

Invariants:
  - Exposes a single route `/api/health` returning JSON.

Failure modes:
  - Missing Flask dependency → ImportError.
  - Port already in use → runtime error.

Example::

    $ python app.py
    # then visit http://localhost:5000/api/health

"""

from flask import Flask, jsonify

app = Flask(__name__)


@app.route('/api/health')
def health() -> tuple[dict, int]:
    """Return a simple health check response."""
    return jsonify({'status': 'ok', 'demo': 'vneil-genesis-python'}), 200


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)