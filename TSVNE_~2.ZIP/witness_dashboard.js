function fetchWitnessLogs() {
  return [
    { id: "W-001", timestamp: "2026-01-21T23:59:00Z", event: "TSVNE START" },
    { id: "W-002", timestamp: "2026-01-22T00:00:01Z", event: "LICENSE GRANTED" },
    { id: "W-003", timestamp: "2026-01-22T00:00:15Z", event: "BOX-7 REGISTERED" }
  ];
}